# Instruções para Deploy no Render.com

Este documento contém instruções detalhadas para implantar o Dashboard de Monitoramento de Produção no Render.com.

## Pré-requisitos

1. Uma conta no [Render.com](https://render.com)
2. Acesso a um repositório Git (GitHub, GitLab, etc.) para hospedar o código

## Estrutura de Arquivos

O pacote de deploy contém os seguintes arquivos:

```
render_deploy/
├── app.py                # Dashboard principal
├── admin.py              # Painel administrativo
├── Procfile              # Configuração para o Render.com
├── requirements.txt      # Dependências do projeto
├── metas.json            # Arquivo de dados (será criado automaticamente)
└── templates/
    ├── login.html        # Template da página de login
    └── dashboard.html    # Template do painel administrativo
```

## Passos para Deploy

### 1. Preparar o Repositório Git

1. Crie um novo repositório no GitHub ou GitLab
2. Faça upload de todos os arquivos deste pacote para o repositório
3. Certifique-se de que o arquivo `Procfile` esteja na raiz do repositório

### 2. Deploy do Dashboard Principal no Render.com

1. Faça login na sua conta do Render.com
2. Clique em "New" e selecione "Web Service"
3. Conecte ao seu repositório Git
4. Configure o serviço:
   - **Nome**: dashboard-producao (ou outro nome de sua preferência)
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:server`
5. Clique em "Advanced" e adicione as seguintes variáveis de ambiente:
   - `PORT`: 8050
6. Clique em "Create Web Service"

### 3. Deploy do Painel Administrativo no Render.com

1. Na sua conta do Render.com, clique em "New" e selecione "Web Service"
2. Conecte ao mesmo repositório Git
3. Configure o serviço:
   - **Nome**: admin-producao (ou outro nome de sua preferência)
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn admin:app`
4. Clique em "Advanced" e adicione as seguintes variáveis de ambiente:
   - `PORT`: 8051
   - `SECRET_KEY`: (gere uma chave aleatória, ex: `python -c "import os; print(os.urandom(24).hex())"`)
   - `ADMIN_USER`: admin (ou outro usuário de sua preferência)
   - `ADMIN_PASS_HASH`: (mantenha vazio para usar a senha padrão "admin123")
5. Clique em "Create Web Service"

### 4. Configurar Comunicação entre Serviços

Após o deploy dos dois serviços, você precisará atualizar a URL da API no arquivo `app.py`:

1. No Render.com, vá para o serviço do painel administrativo e copie a URL
2. Edite o arquivo `app.py` no seu repositório Git
3. Localize a linha que contém `https://seu-painel-admin.onrender.com/api/meta_ativa`
4. Substitua pela URL real do seu painel administrativo + `/api/meta_ativa`
5. Faça commit e push das alterações para o repositório Git
6. O Render.com detectará as alterações e atualizará automaticamente o serviço

## Acesso aos Serviços

Após a conclusão do deploy, você terá acesso aos seguintes serviços:

- **Dashboard de Monitoramento**: https://dashboard-producao.onrender.com
- **Painel Administrativo**: https://admin-producao.onrender.com

Para acessar o painel administrativo, use as credenciais:
- Usuário: `admin` (ou o que você definiu na variável de ambiente)
- Senha: `admin123` (senha padrão)

## Solução de Problemas

Se encontrar problemas durante o deploy:

1. Verifique os logs do serviço no Render.com
2. Certifique-se de que todas as dependências estão listadas no arquivo `requirements.txt`
3. Verifique se as variáveis de ambiente estão configuradas corretamente
4. Certifique-se de que a URL da API no arquivo `app.py` está correta

## Manutenção

Para atualizar o aplicativo no futuro:
1. Faça as alterações necessárias no código
2. Faça commit e push para o repositório Git
3. O Render.com detectará as alterações e atualizará automaticamente os serviços
