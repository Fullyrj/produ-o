import os
import json
import time
import datetime
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

# Configuração do aplicativo Flask para o painel administrativo
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24).hex())  # Chave secreta para sessão

# Configuração do arquivo de metas
METAS_FILE = os.path.join(os.path.dirname(__file__), 'metas.json')

# Inicializa o arquivo de metas se não existir
def init_metas_file():
    if not os.path.exists(METAS_FILE):
        with open(METAS_FILE, 'w') as f:
            json.dump({
                "metas": [
                    {
                        "id": 1,
                        "semana": "22/05/2025 - 28/05/2025",
                        "valor": 1000,
                        "data_criacao": datetime.datetime.now().isoformat(),
                        "ativa": True
                    }
                ]
            }, f)

# Função para obter a meta ativa atual
def get_meta_ativa():
    try:
        with open(METAS_FILE, 'r') as f:
            data = json.load(f)
            for meta in data['metas']:
                if meta['ativa']:
                    return meta
            # Se não encontrar meta ativa, retorna a primeira
            if data['metas']:
                return data['metas'][0]
            return {"valor": 1000}  # Valor padrão
    except:
        return {"valor": 1000}  # Valor padrão em caso de erro

# Função para adicionar nova meta
def add_meta(semana, valor, ativa=False):
    try:
        with open(METAS_FILE, 'r') as f:
            data = json.load(f)
        
        # Gerar novo ID
        new_id = 1
        if data['metas']:
            new_id = max(meta['id'] for meta in data['metas']) + 1
        
        # Se a nova meta for ativa, desativa todas as outras
        if ativa:
            for meta in data['metas']:
                meta['ativa'] = False
        
        # Adiciona nova meta
        data['metas'].append({
            "id": new_id,
            "semana": semana,
            "valor": valor,
            "data_criacao": datetime.datetime.now().isoformat(),
            "ativa": ativa
        })
        
        with open(METAS_FILE, 'w') as f:
            json.dump(data, f, indent=2)
        
        return True
    except Exception as e:
        print(f"Erro ao adicionar meta: {e}")
        return False

# Função para ativar uma meta específica
def activate_meta(meta_id):
    try:
        with open(METAS_FILE, 'r') as f:
            data = json.load(f)
        
        # Desativa todas as metas
        for meta in data['metas']:
            meta['ativa'] = False
            
            # Ativa a meta selecionada
            if meta['id'] == meta_id:
                meta['ativa'] = True
        
        with open(METAS_FILE, 'w') as f:
            json.dump(data, f, indent=2)
        
        return True
    except:
        return False

# Inicializa o arquivo de metas
init_metas_file()

# Credenciais de acesso (em produção, use variáveis de ambiente)
ADMIN_USER = os.environ.get('ADMIN_USER', 'admin')
ADMIN_PASS = os.environ.get('ADMIN_PASS_HASH', generate_password_hash('admin123'))

# Rota para a página de login
@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username == ADMIN_USER and check_password_hash(ADMIN_PASS, password):
            session['logged_in'] = True
            return redirect(url_for('dashboard'))
        else:
            error = 'Credenciais inválidas. Tente novamente.'
    
    return render_template('login.html', error=error)

# Rota para o painel administrativo
@app.route('/dashboard', methods=['GET'])
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    try:
        with open(METAS_FILE, 'r') as f:
            data = json.load(f)
        metas = data['metas']
    except:
        metas = []
    
    return render_template('dashboard.html', metas=metas)

# Rota para adicionar nova meta
@app.route('/add_meta', methods=['POST'])
def add_meta_route():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    semana = request.form['semana']
    valor = int(request.form['valor'])
    ativa = 'ativa' in request.form
    
    if add_meta(semana, valor, ativa):
        return redirect(url_for('dashboard'))
    else:
        return "Erro ao adicionar meta", 500

# Rota para ativar uma meta
@app.route('/activate/<int:meta_id>', methods=['POST'])
def activate_meta_route(meta_id):
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    if activate_meta(meta_id):
        return redirect(url_for('dashboard'))
    else:
        return "Erro ao ativar meta", 500

# Rota para logout
@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

# API para obter a meta ativa (usada pelo dashboard principal)
@app.route('/api/meta_ativa', methods=['GET'])
def api_meta_ativa():
    return jsonify(get_meta_ativa())

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
