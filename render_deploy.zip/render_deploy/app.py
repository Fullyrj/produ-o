import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import random
import pandas as pd
import time
import json
import os
import requests

# Inicializa o aplicativo Dash
app = dash.Dash(__name__)
server = app.server  # Importante para o Gunicorn

# Arquivo para armazenar a meta
METAS_FILE = os.path.join(os.path.dirname(__file__), 'metas.json')

# Função para obter a meta atual
def get_meta_atual():
    try:
        # Tenta obter a meta da API do painel admin
        try:
            # No Render.com, ajuste esta URL para o endereço do seu serviço de admin
            response = requests.get('https://seu-painel-admin.onrender.com/api/meta_ativa')
            if response.status_code == 200:
                return response.json()['valor']
        except:
            pass
        
        # Se a API não estiver disponível, tenta ler do arquivo local
        if os.path.exists(METAS_FILE):
            with open(METAS_FILE, 'r') as f:
                data = json.load(f)
                for meta in data['metas']:
                    if meta['ativa']:
                        return meta['valor']
                if data['metas']:
                    return data['metas'][0]['valor']
    except:
        pass
    
    # Valor padrão se não conseguir obter a meta
    return 1000

# Meta de produção semanal (obtida dinamicamente)
meta_semanal = get_meta_atual()

# Dados iniciais
df = pd.DataFrame({'Tempo': [], 'Interna': [], 'Externa': [], 'Total': [], 'Faltante': []})

app.layout = html.Div([
    html.H1("Monitoramento de Produção", style={'textAlign': 'center', 'color': '#2c3e50', 'marginBottom': 20}),
    
    html.Div([
        html.H3(id='meta-display', style={'textAlign': 'center', 'color': '#27ae60'}),
        html.H3(id='faltante-display', style={'textAlign': 'center', 'color': '#e74c3c'}),
    ], style={'padding': '10px', 'backgroundColor': '#f8f9fa', 'borderRadius': '10px', 'marginBottom': '20px'}),

    html.Div([
        dcc.Graph(id='live-graph'),
    ], style={'padding': '20px', 'backgroundColor': '#f8f9fa', 'borderRadius': '10px', 'boxShadow': '0px 0px 10px rgba(0,0,0,0.1)'}),

    dcc.Interval(
        id='interval-component',
        interval=2000,  # Atualização a cada 2 segundos
        n_intervals=0
    ),
    
    # Intervalo para verificar atualizações na meta (a cada 30 segundos)
    dcc.Interval(
        id='meta-update-interval',
        interval=30000,
        n_intervals=0
    )
], style={'padding': '20px', 'fontFamily': 'Arial, sans-serif'})

@app.callback(
    Output('meta-display', 'children'),
    Input('meta-update-interval', 'n_intervals')
)
def update_meta(n):
    global meta_semanal
    meta_semanal = get_meta_atual()
    return f"Meta Semanal: {meta_semanal} unidades"

@app.callback(
    [Output('live-graph', 'figure'),
     Output('faltante-display', 'children')],
    Input('interval-component', 'n_intervals')
)
def update_graph(n):
    global df, meta_semanal
    
    # Simulação de produção
    interna = random.randint(20, 80)
    externa = random.randint(10, 50)
    total = interna + externa
    
    # Cálculo do faltante considerando a produção acumulada
    total_acumulado = df['Total'].sum() + total if not df.empty else total
    faltante = max(0, meta_semanal - total_acumulado)
    
    novo_tempo = time.strftime('%H:%M:%S')
    
    # Usando concat em vez de append (que está obsoleto)
    df = pd.concat([df, pd.DataFrame({
        'Tempo': [novo_tempo], 
        'Interna': [interna], 
        'Externa': [externa], 
        'Total': [total], 
        'Faltante': [faltante]
    })], ignore_index=True)
    
    # Limitar o número de pontos no gráfico para melhor desempenho
    if len(df) > 30:
        df = df.iloc[-30:]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=df['Tempo'], 
        y=df['Interna'], 
        mode='lines+markers', 
        name='Interna',
        line=dict(color='#3498db', width=2),
        marker=dict(size=8, color='#3498db')
    ))
    
    fig.add_trace(go.Scatter(
        x=df['Tempo'], 
        y=df['Externa'], 
        mode='lines+markers', 
        name='Externa',
        line=dict(color='#2ecc71', width=2),
        marker=dict(size=8, color='#2ecc71')
    ))
    
    fig.add_trace(go.Scatter(
        x=df['Tempo'], 
        y=df['Total'], 
        mode='lines+markers', 
        name='Total',
        line=dict(color='#9b59b6', width=3),
        marker=dict(size=10, color='#9b59b6')
    ))

    fig.update_layout(
        title={
            'text': "Produção ao Longo do Tempo",
            'y': 0.95,
            'x': 0.5,
            'xanchor': 'center',
            'yanchor': 'top'
        },
        xaxis_title="Tempo",
        yaxis_title="Produção",
        template="plotly_white",
        height=500,
        margin=dict(l=40, r=40, t=60, b=40),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )

    return fig, f"Faltante para Meta: {faltante} unidades"

# Inicializa o arquivo de metas se não existir
def init_metas_file():
    if not os.path.exists(METAS_FILE):
        with open(METAS_FILE, 'w') as f:
            json.dump({
                "metas": [
                    {
                        "id": 1,
                        "semana": "22/05/2025 - 28/05/2025",
                        "valor": 1000,
                        "data_criacao": time.strftime("%Y-%m-%dT%H:%M:%S"),
                        "ativa": True
                    }
                ]
            }, f)

# Inicializa o arquivo de metas
init_metas_file()

if __name__ == '__main__':
    app.run_server(debug=False, host='0.0.0.0')
